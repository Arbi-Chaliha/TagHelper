using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using TagHelpers.Models;

namespace TagHelpers.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [Route("")]
        public IActionResult Index()//this action method will work for get request,this will show us the view of our page as well as our form
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(Employee e) { //this action method will diaplay the page after clicking submit button
            return View();
        }
        /* public IActionResult Contact()
         {
             return View();
         }*/
        public int Contact(int id)
        {
            return id;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
