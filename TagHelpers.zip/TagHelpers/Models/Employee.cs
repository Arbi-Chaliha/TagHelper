﻿using System.ComponentModel.DataAnnotations;

namespace TagHelpers.Models
{
    public class Employee
    {
        [Required] 
        public string name { get; set; }
        public int age { get; set; }
        public string designation { get; set; }
        public int salary { get; set; }
    }
}
